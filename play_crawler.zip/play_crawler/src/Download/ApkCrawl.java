package Download;

import java.util.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;



import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;

import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.params.CookiePolicy;
import org.apache.http.client.params.HttpClientParams;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;


import sun.audio.AudioPlayer;
import sun.audio.AudioStream;

public class ApkCrawl{

	/**
	 * @param args
	 */	
	private static Set<String> doneSet  = new HashSet<String>();
	private static Set<String> NotFreeSet = new HashSet<String>();
	private static Queue<String> readyQ  = new LinkedList<String>();  
    private static Queue<String> account  = new LinkedList<String>();  
    private static Queue<String> passwd  = new LinkedList<String>();
    
    private Date currentTime;
    private static int APIUsedTimes;
    private static final int BannedTimes = 100;
	private static GoogleAccount ga;
    private static ApkDownloader d;
    private static FileOperation fo;
    
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ApkCrawl crawler = new ApkCrawl();
		String tmp;
		try{
				if (args[0].equals("apk")){					
					crawler.GetAccount();	
					while (!crawler.login()); 
					APIUsedTimes = 0;
					try{
						if (args[1].equals("0"))   
							crawler.CrawlFromURL(Constant.GooglePlayURL);
						if (args[1].equals("1"))
								crawler.CrawlFromURL(args[2]);
					}catch(Exception e){
						fo.RecordFile(e.getMessage(),Constant.LogFile);
						fo.CreateReadyWriter();
						while ((tmp = crawler.PopApk()) != null) fo.RecordReadyApp(tmp);
						fo.CloseReadyWriter();
					}
					if (args[1].equals("2")) 
							crawler.CrawlWithApkId(args[2]);
					if (args[1].equals("3"))
							crawler.CrawlWithDeveloper(args[2]);
				}
				if (args[0].equals("info"))
				{
					crawler.GetAccount();	
					while (!crawler.login()); 
					if (args[1].equals("0"))
						crawler.InfoWithFile(Constant.FinishedAppRecord);
					if (args[1].equals("1")) 
						crawler.InfoWithApkId(args[2]);
				}
				if (args[0].equals("sha1"))	new SHA1().Sha1All();					
				if (args[0].equals("help"))
				{
					System.out.println("--------------------The Input Format of Crawler-----------------------");
					System.out.println("############Apk File Part");
					System.out.println("java -jar PlayCrawler apk 0:  	 Crawling apk files from " + Constant.GooglePlayURL);
					System.out.println("java -jar PlayCrawler apk 1 url:     Crawling apk files from the url user inputs");
					System.out.println("java -jar PlayCrawler apk 2 apkId:   Crawling the specific apk file with package name user inputs");
					System.out.println("java -jar PlayCrawler apk 3 Devlp:   Crawling the apk files related to the developer name user inputs");
					System.out.println("############MetaInfo File Part");
					System.out.println("java -jar PlayCrawler info 0: 		 Crawling metainfo files of those downloaded app.");
					System.out.println("java -jar PlayCrawler info 1 apkId:    Crawling metainfo files of the app user inputs");
					System.out.println("############Sha1 Part");
					System.out.println("java -jar PlayCrawler Sha1:          Change the name of both apk file and txt file into Sha1 format");		
				}					
		}catch(Exception e){
				fo.RecordFile("--------------All accounts are died!-----------------", Constant.LogFile);
		}		
		//crawler.InfoWithFile(Constant.MetaNeed);
	}	
	public ApkCrawl() throws Exception{
		super();
		// TODO Auto-generated constructor stub
		ga = new GoogleAccount();
		fo = new FileOperation();
		GetDoneAndNotFreeAndReadySet();
		//d.testDownload("com.rovio.angrybirds");
	}
	
	// Account related part
	private boolean login() throws Exception {
		// TODO Auto-generated method stub
		String acc = NextAccount();
		String pass= NextPasswd();
		if (acc == null) throw new Exception();
		try{			
			fo.RecordFile("----------------------------New Login----------------------------------",Constant.LogFile);
			fo.RecordFile("###Please wait 10 seconds to login", Constant.LogFile);
			fo.RecordFile("Account: " + acc ,Constant.LogFile);
			fo.RecordFile("Passwd : " + pass,Constant.LogFile);	 
			d = new ApkDownloader(acc,pass);
			fo.RecordFile("--------------------------Login Complete-------------------------------",Constant.LogFile);
			return true;
		}catch(Exception e){
			fo.RecordFile("--------------------------Account die: "  + acc +  "-------------------",Constant.LogFile);
			System.out.println(e.getMessage());
			return false;
		}
	}
	private void GetAccount() throws IOException {
		// TODO Auto-generated method stub
		BufferedReader reader=new BufferedReader(new InputStreamReader(new FileInputStream(Constant.GOOGLE_ACOUNT),"UTF8"));
		try{
			String tmp1,tmp2;
			while ((tmp1 = reader.readLine()) != null){
				tmp2 = reader.readLine();
				account.offer(tmp1);
				passwd.offer(tmp2);
			}
		}catch(IOException e){
			System.out.println(account.size());
		}
		reader.close();
	}
	private String NextAccount(){
		String acc = account.poll();
		return acc;		
	}
	private String NextPasswd(){

		String pass = passwd.poll();
		return pass;		
	}
	
	private void CrawlWithApkId(String apkId) throws Exception{
		String apk;
		PushApk(apkId);
		currentTime = new Date(); 
		if ((apk = PopApk())!= null)
		{			
			fo.RecordFile(apk +"  is now trying to be downloaded!  " + currentTime.toGMTString(), Constant.LogFile);
			if (d.testDownload(apk) == 2){
				ReadyToDone(apk);
				fo.RecordFinishedApp(apk);
				currentTime = new Date(); 
				fo.RecordFile(apk +"  has been downloaded successfully!  " + currentTime.toGMTString(), Constant.LogFile);
			}				
			else{
				fo.RecordNotFree(apk);
				currentTime = new Date(); 
				fo.RecordFile(apk +"  is not free!  " + currentTime.toGMTString(), Constant.LogFile);
			}
		}
		else{
			if (NotFreeSet.contains(apkId))
				fo.RecordFile(apkId +"  is not free!  " + currentTime.toGMTString(), Constant.LogFile);
			else
				fo.RecordFile(apkId +"  already exists!  " + currentTime.toGMTString(), Constant.LogFile);
		}		
	}
	private void CrawlWithDeveloper(String developer) throws Exception {
		// TODO Auto-generated method stub
		String apkId;			
		
		fo.RecordFile("Crawling from : " + Constant.DeveloperURLBase + developer, Constant.LogFile);
		FindApk(Constant.DeveloperURLBase + developer);		
		System.out.println(readyQ.size());
		while ((apkId = PopApk())!= null){
			currentTime = new Date();
			switch (d.testDownload(apkId)){
			case 2: //successfully downloaded!
			{
				ReadyToDone(apkId);
				fo.RecordFinishedApp(apkId);
				currentTime = new Date(); 
				fo.RecordFile(apkId +"  has been downloaded successfully!  " + currentTime.toGMTString(), Constant.LogFile);
				break;
			}	
			case 1: //not free
			{
				fo.RecordNotFree(apkId);
				currentTime = new Date(); 
				fo.RecordFile(apkId +"  is not free!  " + currentTime.toGMTString(), Constant.LogFile);
				break;
			}
			case 0: //exist
			{				
				fo.RecordFile(apkId +"  already exists!  " + currentTime.toGMTString(), Constant.LogFile);
				ReadyToDone(apkId);
				fo.RecordFinishedApp(apkId);
				break;
			}
			default: 
			}
		}		
		fo.RecordFile("--------------------------All apks of this developer have been downloaded-------------------------------",Constant.LogFile);
	}
	private void CrawlFromURL(String url) throws Exception {
		String apkId;
		int getback;
		FindApk(url);		
		System.out.println(readyQ.size());
		while ((apkId = PopApk())!= null){
			currentTime = new Date();
			switch (getback = d.testDownload(apkId)){
				case 4:	// accounts die!
				{
					login();
					break;
				}
				case 3:	// handlable error!
				{
					break;
				}
				case 1: //not free
				{
					fo.RecordNotFree(apkId);
					currentTime = new Date(); 
					fo.RecordFile(apkId +"  is not free!  " + currentTime.toGMTString(), Constant.LogFile);
					break;
				}
				case 0: //exist
				{				
					fo.RecordFile(apkId +"  already exists!  " + currentTime.toGMTString(), Constant.LogFile);
					ReadyToDone(apkId);
					fo.RecordFinishedApp(apkId);
					break;
				}
				default: //successfully downloaded!
				{
					ReadyToDone(apkId);
					fo.RecordFinishedApp(apkId);
					currentTime = new Date(); 
					fo.RecordFile(apkId +"  has been downloaded successfully!  " + currentTime.toGMTString(), Constant.LogFile);
					fo.RecordFile(apkId +"  is trying to downloaded metainfo!  ", Constant.LogFile);
					this.InfoWithApkId(apkId,getback-5);
					fo.RecordFile(apkId +"  has downloaded metainfo!  ", Constant.LogFile);
				}	
			}			
			FindApk(Constant.ApkURLBase + apkId);
		}		
		fo.RecordFile("--------------------------All apk from this URL have been downloaded-------------------------------",Constant.LogFile);
	}
	
	private void InfoWithFile(String fn) throws IOException{
		// TODO Auto-generated method stub
		int i = 0;
		BufferedReader reader;
		try{
			reader = new BufferedReader(new InputStreamReader(new FileInputStream(fn),"UTF8"));
			String apkId;
			while ((apkId = reader.readLine()) != null){
				if ( apkId.equals("") ) continue;
				if (fo.CheckInfoExist(apkId)) {
					fo.RecordFile("Meta info already exists for " + apkId, Constant.LogFile);
					continue;
				}
				String info = d.testDetails(apkId);
				if (info.equals("Wrong!")){
					fo.RecordFile("Something wrong happens in " + apkId, Constant.LogFile);
					if (i++ > 500){
						fo.RecordFile("--------------------------Account die -----------------------",Constant.LogFile);
						try{
								while (!login()); 
						}catch(Exception e){
								fo.RecordFile("--------------All accounts are died!-----------------", Constant.LogFile);
								throw new Exception("adfas");
						}
						d.testDetails(apkId);
						i = 0;
					}
				}else{	
					i = 0;				
					fo.RecordFile(info, Constant.MetaInfoDir + apkId + ".txt");
					fo.RecordFile("Successfully crawl info of " + apkId, Constant.LogFile);
				}
			}
			reader.close();
		}catch(Exception e){
			fo.RecordFile("---------------Exit out of the InfoWithFile------------------",Constant.LogFile);
		}
	}
	private void InfoWithApkId(String apkId) {
		// TODO Auto-generated method stub		
		try{
			String info = d.testDetails(apkId);
			fo.RecordFile(info, Constant.MetaInfoDir + apkId + ".txt");
			
		}catch(Exception e){}		
	}
	private void InfoWithApkId(String apkId,int vercode) {
		// TODO Auto-generated method stub		
		try{
			String info = d.testDetails(apkId);
			fo.RecordFile(info, Constant.MetaInfoDir + apkId + "_" + vercode + ".txt");
			
		}catch(Exception e){}		
	}
		
	
	private void FindApk(String url) throws IOException{
			String apkId,tmp;
	  		ga.GetPage(url, "currentView.html");
	  		BufferedReader reader=new BufferedReader(new InputStreamReader(new FileInputStream("currentView.html"),"UTF8"));
	  		while ((tmp = reader.readLine())!= null){
	  			while (tmp.indexOf((Constant.ApkSignInPage )) != -1){
	  				tmp = tmp.substring(tmp.indexOf(Constant.ApkSignInPage ), tmp.length()-1);
	  				tmp = tmp.substring(12,tmp.length()-1);
	  				apkId = tmp.substring(0,tmp.indexOf("\""));
	  				tmp = tmp.substring(tmp.indexOf("\""),tmp.length()-1);
	  				PushApk(apkId);
	  			}
	  		}
	  		reader.close();
	 }
	private void PushApk(String apkId) {
		// TODO Auto-generated method stub
		if (readyQ.contains(apkId) || NotFreeSet.contains(apkId)) return;
		readyQ.offer(apkId);
	}
	private String PopApk(){
		if (readyQ.isEmpty()) 
			return null;
		else 
			return (String)readyQ.poll();
	}
	private void ReadyToDone(String apkId){
		doneSet.add(apkId);
	}	
	public void GetDoneAndNotFreeAndReadySet() throws IOException{
		String tmp;
		BufferedReader reader=new BufferedReader(new InputStreamReader(new FileInputStream(Constant.FinishedAppRecord),"UTF8"));
		while ((tmp = reader.readLine())!= null){
			if (!tmp.equals("")) doneSet.add(tmp);
  		}
		reader.close();
		BufferedReader reader2=new BufferedReader(new InputStreamReader(new FileInputStream(Constant.NotFreeAppRecord),"UTF8"));
		while ((tmp = reader2.readLine())!= null){
			if (!tmp.equals("")) NotFreeSet.add(tmp);
  		}
		reader2.close();
		BufferedReader reader3=new BufferedReader(new InputStreamReader(new FileInputStream(Constant.ReadyAppRecord),"UTF8"));
		while ((tmp = reader3.readLine())!= null){
			if (!tmp.equals("")) readyQ.offer(tmp);
  		}
		reader3.close();
	}	

}
