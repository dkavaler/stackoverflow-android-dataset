package Download;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class SHA1 {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws NoSuchAlgorithmException 
	 */
	private static String apkfile,txtfile,sha1apk,cmd1,cmd2;
	private static MessageDigest sha1;
	private static FileInputStream fis;
	private static Process process; 
	private static BufferedReader reader;
	private static Runtime rn;
	public static byte[] data;
	public SHA1() throws Exception{
		 reader = new BufferedReader(new InputStreamReader(new FileInputStream(Constant.FinishedAppRecord),"UTF8")); //here
		 rn = Runtime.getRuntime();
		 sha1 = MessageDigest.getInstance("SHA1");
	}
	public void Sha1All() throws Exception {
		// TODO Auto-generated method stub
		 	String apkId = null,fn;
		 	File dir = new File(Constant.DownloadDir);
	        File file[] = dir.listFiles();
	        for (int i = 0; i < file.length; i++) {
	        	fn = file[i].getName();
	        	if (fn.lastIndexOf("_")>0)
	        	{
	        	   apkId = fn.substring(0, fn.lastIndexOf("_"));
		           System.out.println(apkId);
		           String cmd = "mv " + Constant.MetaInfoDir + apkId + ".txt " + Constant.MetaInfoDir + fn + ".txt";
		           process = rn.exec(cmd);
				   process.waitFor();
				   process.getErrorStream().close();
				   process.getInputStream().close();
				   process.getOutputStream().close();
				   process.destroy();
				   System.out.println("End execution!!!!!!!!!!!!!" + apkId +" into "+fn);
				}/*
	            if (apkId.equals(""))	continue;	 				 
				 apkfile = Constant.DownloadDir + fn;  //here
				 txtfile = Constant.MetaInfoDir + apkId + ".txt";
				 try{						 
					 System.out.println("---------------------" + apkId + "---------------------------");
					 sha1apk = Sha1(apkfile);
					 System.out.println(apkfile + '\n');
					 cmd1 = "cp " + apkfile + " " + Constant.Sha1Dir +sha1apk + ".apk";
					 System.out.println("Start execution cmd1:  " + cmd1);
					 process = rn.exec(cmd1);
					 process.waitFor();
					 process.getErrorStream().close();
					 process.getInputStream().close();
					 process.getOutputStream().close();
					 process.destroy();
					 System.out.println("End execution!!!!!!!!!!!!!" );
					 File f = new File(txtfile);
					 if (f.exists()){
						 cmd2 = "cp " + txtfile + " " + Constant.Sha1Dir + sha1apk + ".txt";
						 System.out.println("Start execution cmd2:  " + cmd2);
						 process = rn.exec(cmd2);
						 process.waitFor();
						 process.getErrorStream().close();
						 process.getInputStream().close();
						 process.getOutputStream().close();
						 process.destroy();
						 System.out.println("End execution!!!!!!!!!!!!!!" );
					 }
						 System.out.println("--------------------------------------------------------------");
					 }catch (FileNotFoundException e){
						System.out.println("Don't exist!");
		}*/
	        }
	}
	public String Sha1(String file) throws NoSuchAlgorithmException, IOException
    {
		fis = new FileInputStream(file);  
        data = new byte[1024];
        int read = 0; 
        while ((read = fis.read(data)) != -1) {
            sha1.update(data, 0, read);
        };
        byte[] hashBytes = sha1.digest();
  
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < hashBytes.length; i++) {
          sb.append(Integer.toString((hashBytes[i] & 0xff) + 0x100, 16).substring(1));
        }
        fis.close(); 
        String fileHash = sb.toString();         
        return fileHash;
    }

}
