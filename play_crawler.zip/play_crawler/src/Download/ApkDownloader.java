package Download;

import java.io.FileOutputStream;
import java.io.InputStream;

import org.apache.http.HttpHost;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.params.ConnRoutePNames;
import org.apache.http.impl.client.DefaultHttpClient;

import com.akdeniz.googleplaycrawler.GooglePlay.AggregateRating;
import com.akdeniz.googleplaycrawler.GooglePlay.AppDetails;
import com.akdeniz.googleplaycrawler.GooglePlay.DetailsResponse;
import com.akdeniz.googleplaycrawler.GooglePlay.DocV2;
import com.akdeniz.googleplaycrawler.GooglePlay.Offer;
import com.akdeniz.googleplaycrawler.GooglePlayAPI;
import com.akdeniz.googleplaycrawler.Utils;





/**
 * 
 * @author akdeniz
 * 
 */
public class ApkDownloader{

    // your device id, which can be optained from Gtalk Service Monitor(aid key)
    // by "*#*#8255#*#*" combination, but you dont need one.
    
	private static GooglePlayAPI service,service2;
    private static FileOperation fo;
    private static HttpClient getProxiedHttpClient(String host, Integer port) throws Exception {
		HttpClient client = new DefaultHttpClient(GooglePlayAPI.getConnectionManager());
		client.getConnectionManager().getSchemeRegistry().register(Utils.getMockedScheme());
		HttpHost proxy = new HttpHost(host, port);
		client.getParams().setParameter(ConnRoutePNames.DEFAULT_PROXY, proxy);
		return client;
	}
    public ApkDownloader(String account,String passwd) throws Exception {

		// TODO Auto-generated constructor stub
    	System.gc();
    	fo = new FileOperation();
    	service = new GooglePlayAPI(account, passwd);
//		service.setClient(getProxiedHttpClient("localhost", 8888)); //Integer.valueOf(Constant.port)));
		//service.uploadDeviceConfig();
		service.checkin();
		Thread.sleep(5000); // allow server to catch up...
		service.login();
		System.out.println("SubAuthToken : " + service.getToken());
		System.out.println("AndroidId : " + service.getAndroidID());
		System.out.println("SecurityToken : "+ service.getSecurityToken());		
		service.uploadDeviceConfig();
	}
    static int getVersionCode(String apkId) throws Exception{
    	service2 = new GooglePlayAPI();
		DetailsResponse details = service2.details(apkId);
		System.out.println("Ok 2!");
		AppDetails appDetails = details.getDocV2().getDetails().getAppDetails();
		int versionCode = appDetails.getVersionCode();
		System.out.println("Ok 5!" + versionCode);
		return versionCode;
    }
    int testDownload(String apkId) throws Exception {
    	try{
	    	System.out.println("Ok 1!");
			DetailsResponse details = service.details(apkId);
			System.out.println("Ok 2!");
			AppDetails appDetails = details.getDocV2().getDetails().getAppDetails();
			System.out.println("Ok 3!");
			Offer offer = details.getDocV2().getOffer(0);
			System.out.println("Ok 4!");		
			int versionCode = appDetails.getVersionCode();
			System.out.println("Ok 5!" + versionCode);
			long installationSize = appDetails.getInstallationSize();
			System.out.println("Ok 6!");
			int offerType = offer.getOfferType();
			System.out.println("Ok 7!");
			boolean checkoutRequired = offer.getCheckoutFlowRequired();
			// paid application...ignore
			if (fo.CheckApkFileExist(apkId + "_" + versionCode)) return 0;
			if (checkoutRequired) 						  	     return 1;
			System.out.println("Ok 8!");
			System.out.println("Downloading..." + appDetails.getPackageName() + " : " + installationSize + " bytes");
		
			InputStream downloadStream = service.download(appDetails.getPackageName(), versionCode, offerType);
		
			FileOutputStream outputStream = new FileOutputStream(Constant.DownloadDir + apkId + "_" + versionCode + ".apk");
		
			byte buffer[] = new byte[1024];
			for (int k = 0; (k = downloadStream.read(buffer)) != -1;) {
			    outputStream.write(buffer, 0, k);
			}
			downloadStream.close();
			outputStream.close();
			//System.out.println("Downloaded! " + appDetails.getPackageName() + ".apk");
			return 5+versionCode;
    	}catch(Exception e)
    	{
    		System.out.println("im here");
    		System.out.println(e.getMessage());
    		if (e.getMessage().contains("device is not compatible")) {
    			System.out.println("Skipping APK for device incompatibility");
    			return 3;
    		}
    		if (e.getMessage().contains("found") 
    		 || e.getMessage().contains("retrieving") 
    		 || e.getMessage().contains("not available on your carrier")
    		 || e.getMessage().contains("purchase") 
    		 || e.getMessage().contains("This item")
    		 || e.getMessage().contains("clients.google.com")
    		 || e.getMessage().contains("Not Found")
    		 || e.getMessage().contains("No space")
    		 || e.getMessage().contains("Premature end of")) 
    			{
    			    fo.RecordFile("DownloadProblem " + apkId + " " + e.getMessage(), Constant.LogFile);
    				return 3;
    			}
    		if (e.getMessage().contains("Please try again in 30 seconds"))
    		{
    			Thread.sleep(30000);
    			return 3;
    		}
    		else if (e.getMessage().contains("Unauthorized"))	return 4;
    			 else throw e;
    	}
    }

         String testDetails(String apkId){
        	 try{
        		 System.out.println("Ok 1!"+apkId);
        	 DetailsResponse detailsResponse = service.details(apkId);
        	 System.out.println("Ok 0!");
        	 DocV2 doc = detailsResponse.getDocV2();
        	 System.out.println("Ok 3!");
        	 AppDetails detail = doc.getDetails().getAppDetails();
        	 System.out.println("Ok 2!");
        	 AggregateRating rate = doc.getAggregateRating();
        	 System.out.println("Ok 4!");
        	 StringBuffer info = new StringBuffer();
        	 System.out.println("1.Last Updated      " + detail.getUploadDate());
        	 info.append(detail.getUploadDate()   	 +"\r\n");
        	 System.out.println("2.Avg rating        " + rate.getStarRating());
        	 info.append(rate.getStarRating()        +"\r\n");
        	 System.out.println("3.No of rating      " + rate.getRatingsCount());
        	 info.append(rate.getRatingsCount()  	 +"\r\n");
        	 System.out.println("4.Category          " + detail.getAppCategory(0));
        	 info.append(detail.getAppCategory(0)    +"\r\n");
        	 System.out.println("5.No of downloaded  " + detail.getNumDownloads());
        	 info.append(detail.getNumDownloads()    +"\r\n");
        	 System.out.println("6.Developer name    " + detail.getDeveloperName());
        	 info.append(detail.getDeveloperName()   +"\r\n");
        	 System.out.println("7.Developer site    " + detail.getDeveloperWebsite());
        	 info.append(detail.getDeveloperWebsite()+"\r\n");
        	 System.out.println("8.Developer email   " + detail.getDeveloperEmail());
        	 info.append(detail.getDeveloperEmail()  +"\r\n");
        	 System.out.println("9.App url          " + "https://market.android.com/details?id=" + detail.getPackageName());
        	 info.append(detail.getPackageName()     +"\r\n");
        	 System.out.println("10.Description       " + doc.getDescriptionHtml());
        	 info.append(doc.getDescriptionHtml()    +"\r\n");
        	 return info.toString();
        	 }catch (Exception e){
        		 System.out.println(e.getMessage());        		 
        		 return "Wrong!";
        	 }
        }

}
