package Download;

public class Constant {
	public static final String DownloadDir = "apk/" ;
    public static final String MetaInfoDir = "metainfo/";
    public static final String Sha1Dir     = "sha1/";
    
	public static final String DeviceId = "g1ee438e96b2bcc34";
	public static final String ANDROID_ID = "33db1484276a5809";
	
	public static final String FinishedAppRecord = "FinishedApp.txt";
	public static final String NotFreeAppRecord  = "NotFree.txt";
	public static final String ReadyAppRecord	 = "ReadyApp.txt";
	public static final String LogFile			 = "Log.txt";
    public static final String GOOGLE_ACOUNT 	 = "Accounts.txt";
    public static final String host = "localhost";
    public static final int port= 8888;
    
    public static String ApkURLBase = "https://play.google.com/store/apps/details?id=";
	public static String DeveloperURLBase = "https://play.google.com/store/apps/developer?id=";
	public static String GooglePlayURL = "https://play.google.com/store/apps";
	public static String ApkSignInPage = "data-docid=";
}
