package Download;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class FileOperation {
	FileWriter writerR;
	public FileOperation() throws IOException{

		  File f = new File(Constant.DownloadDir);
		  if (!f.exists()) f.mkdir();
		  f = new File(Constant.MetaInfoDir);
		  if (!f.exists()) f.mkdir();
		  f = new File(Constant.Sha1Dir);
		  if (!f.exists()) f.mkdir();
		  f = new File(Constant.NotFreeAppRecord);
		  if (!f.exists()) 
			  {
			  		f.createNewFile();
			  }
		  else ;
		  f = new File(Constant.FinishedAppRecord);
		  if (!f.exists()) f.createNewFile();
		  f = new File(Constant.ReadyAppRecord);
		  if (!f.exists()) f.createNewFile();
	}
	public boolean CheckApkFileExist(String filename) throws IOException {
		  String fn = Constant.DownloadDir + filename + ".apk";
		  File f = new File(fn);
		  if (f.exists()) return true;
		  return false;
	}
	public boolean CheckInfoExist(String apk) throws IOException {
		  String fn = Constant.MetaInfoDir + apk + ".txt";
		  File f = new File(fn);
		  if (f.exists()) return true;
		  return false;
	}
	public void RecordFinishedApp(String apkId) throws IOException{		
		if (!apkId.equals(""))  
		RecordFile(apkId,Constant.FinishedAppRecord);
	}
	public void RecordNotFree(String apkId) throws IOException{
		if (!apkId.equals(""))	
		 RecordFile(apkId,Constant.NotFreeAppRecord);
	}
	public void CreateReadyWriter() throws IOException{
		writerR = new FileWriter(Constant.ReadyAppRecord,false);
	}
	public void CloseReadyWriter() throws IOException{
		writerR.close();
	}
	public void RecordReadyApp(String tmp) throws IOException {
		// TODO Auto-generated method stub
		System.out.println(tmp);		
		writerR.write(tmp);
		writerR.write(13);
	    writerR.write(10);	       
	}
	public void RecordFile(String text,String fn) throws IOException{
		System.out.println(text);
		FileWriter writer = new FileWriter(fn, true);
	    writer.write(13);
	    writer.write(10);
	    writer.write(text);	    
	    writer.close();
	}
	
}
