package Download;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.params.CookiePolicy;
import org.apache.http.client.params.HttpClientParams;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;

public class GoogleAccount {
	
	private final static DefaultHttpClient httpclient = new DefaultHttpClient();
	private static HttpResponse response;
	private String usr;
	private String psw; 
	
	public GoogleAccount() {
		super();
		// TODO Auto-generated constructor stub
		usr = "relief2054@gmail.com";
		psw = "relief2054!";
	}
	public GoogleAccount(String usr,String psw) {
		super();
		// TODO Auto-generated constructor stub
		this.usr = usr;
		this.psw = psw;
	}
	public void login() throws ClientProtocolException, IOException, JSONException {
		
		// TODO Auto-generated method stub
		//access servlet by get and get yzm
		GetPage("https://accounts.google.com/ServiceLogin","1.html");		
		
		List<NameValuePair> paras=new ArrayList<NameValuePair>();
        paras.add(new BasicNameValuePair("continue","https://play.google.com/store/apps/details?id=net.sylark.apkextractor&amp;hl=en"));
     	paras.add(new BasicNameValuePair("followup","https://play.google.com/store/apps/details?id=net.sylark.apkextractor&amp;hl=en"));
     	paras.add(new BasicNameValuePair("service","googleplay"));
     	paras.add(new BasicNameValuePair("dsh",getdash()));//
     	paras.add(new BasicNameValuePair("hl","en"));
     	paras.add(new BasicNameValuePair("GALX",getgalx()));//
     	paras.add(new BasicNameValuePair("timeStmp","timeStmp"));     	
     	paras.add(new BasicNameValuePair("secTok","secTok"));
     	paras.add(new BasicNameValuePair("_utf8","&#9731;"));
     	paras.add(new BasicNameValuePair("bgresponse","js_disabled"));
     	paras.add(new BasicNameValuePair("Email",usr));
     	paras.add(new BasicNameValuePair("Passwd",psw));
    	paras.add(new BasicNameValuePair("signIn","Sign in"));    	
    	paras.add(new BasicNameValuePair("PersistentCookie","yes"));
     	paras.add(new BasicNameValuePair("rmShown","1"));
     	PostPage("https://accounts.google.com/ServiceLoginAuth",paras,"2.html");
     	//System.out.println(response.getStatusLine());
     	
     	GetPage("https://play.google.com/store/apps","3.html");
        System.out.println("Login done!");
	}
	public void PostPage(String url, List<NameValuePair> paras, String fn) throws IOException {
		// TODO Auto-generated method stub
		HttpPost post = new HttpPost(url);
		post.setEntity(new UrlEncodedFormEntity(paras,"utf-8"));
		response = httpclient.execute(post);
		output(fn,response);
		EntityUtils.consume(response.getEntity());
	}
	public void GetPage(String url,String fn) throws IOException{
    	HttpGet httpget = new HttpGet(url);
		//Execute get
	   	HttpClientParams.setCookiePolicy(httpclient.getParams(), CookiePolicy.BROWSER_COMPATIBILITY);
		response = httpclient.execute(httpget);
		output(fn,response);	
		EntityUtils.consume(response.getEntity());
    }
	private static void output(String fn,HttpResponse response) throws IOException{
     	if (fn != null){
			File file = new File(fn);
			OutputStream ops = new FileOutputStream(file);
			response.getEntity().writeTo(ops);
			ops.close();
		}
	}
	private static String getdash() throws IOException{
		BufferedReader ofile=new BufferedReader(new InputStreamReader(new FileInputStream("1.html"),"UTF8"));
	    String s;
	    String s1 = "name=\"dsh\"";
	      while ((s = ofile.readLine()) != null)
	        {
	     			s = s.trim();
	     			
	     			if (s.lastIndexOf(s1) != -1) {
	     				//System.out.println(s);
	     				//System.out.println(s.substring(27, s.length()-1));
	     				return s.substring(27, s.length()-1);
	     			}
	     			
	        }
	 	 // ofile.readLine(); ofile.readLine();
	 	  //s = ofile.readLine().trim();
	 	  return s;
	}
	private static String getgalx() throws IOException{
		BufferedReader ofile=new BufferedReader(new InputStreamReader(new FileInputStream("1.html"),"UTF8"));
	    String s;
	    String s1 = "name=\"GALX\"";
	      while ((s = ofile.readLine()) != null)
	        {
	     			s = s.trim();
	     			if (s.lastIndexOf(s1) != -1) {
	     				s = ofile.readLine().trim();
	     				//System.out.println(s);
	     				//System.out.println(s.substring(7,s.length()-2));
	     				return s.substring(7,s.length()-2);
	     			}
	        }
	 	 // ofile.readLine(); ofile.readLine();
	 	  
	 	  return s;
	}
	public String gettoken() throws IOException{
		BufferedReader ofile=new BufferedReader(new InputStreamReader(new FileInputStream("3.html"),"UTF8"));
	    String s;
	    String s1 = "token: ";
	      while ((s = ofile.readLine()) != null)
	        {
	     			s = s.trim();
	     			if (s.lastIndexOf(s1) != -1) {
	     				s = s.substring(s.lastIndexOf(s1), s.length()-1);
		     			//System.out.println(s);
		     			s = s.substring(8,s.length()-1);
	     				//System.out.println(s);
	     				s = s.substring(0,s.indexOf("'"));
	     				//System.out.println(s);
	     				return s;
	     			}
	     			
	        }
	 	 // ofile.readLine(); ofile.readLine();
	 	  //s = ofile.readLine().trim();
	 	  return s;
	}
	public void AppDownload(String apk) throws ClientProtocolException, IOException {
		// TODO Auto-generated method stub
		  /*HttpPost ajaxpost = new HttpPost("http://10.10.10.25:7070/xgxt/xtwh/login_getUserAllMenu.html");
		  HttpResponse response = httpclient.execute(ajaxpost);
		  output("C:/Users/xieyu/Desktop/ajax",response);*/
		  
	      List<NameValuePair> paras2=new ArrayList<NameValuePair>();
	      paras2.add(new BasicNameValuePair("id",apk));
	      paras2.add(new BasicNameValuePair("offerType","1"));//g1ee438e96b2bcc34	      
	      paras2.add(new BasicNameValuePair("device",Constant.DeviceId));
	      paras2.add(new BasicNameValuePair("xhr","1"));
	      paras2.add(new BasicNameValuePair("token",gettoken()));
	      PostPage("https://play.google.com/store/install", paras2, null);
	}
    
 }